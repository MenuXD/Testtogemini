package com.example.menu_xd_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
