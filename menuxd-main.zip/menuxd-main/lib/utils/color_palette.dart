import 'package:flutter/cupertino.dart';

class ColorPalette{
  static final gray = Color(0xff555F69);
  static final gray2 = Color(0xffAAAFB4);
  static final melon = Color(0xffFA456F);
}